# AI Resume Analyzer

Simple Flask web app that analyzes resume text, extracts skills, and gives a score.

## Run
pip install -r requirements.txt
python app.py
