from flask import Flask, render_template, request
import re

app = Flask(__name__)

def analyze_resume(text):
    skills = ["Python","Java","SQL","Machine Learning","HTML","CSS","JavaScript","Flask"]
    found = [s for s in skills if s.lower() in text.lower()]
    score = min(len(found) * 12, 100)
    return found, score

@app.route("/", methods=["GET","POST"])
def index():
    skills = []
    score = None
    if request.method == "POST":
        text = request.form.get("resume_text","")
        skills, score = analyze_resume(text)
    return render_template("index.html", skills=skills, score=score)

if __name__ == "__main__":
    app.run(debug=True)
